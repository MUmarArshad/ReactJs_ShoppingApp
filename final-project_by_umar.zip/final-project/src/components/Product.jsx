import { FavoriteBorderOutlined, SearchOutlined, ShopOutlined, ShoppingCartOutlined } from "@material-ui/icons"
import { styled } from "styled-components";
import { Link } from "react-router-dom";
const Container = styled.div`
margin: 5px;
flex : 1;
min-width: 280px;
height: 350px;
display: flex;
align-items: center;
justify-content: center;
background-color: #e8f0f8da;
position: relative;
&:hover{
    scale: 1.04;
}
`
const Circle = styled.div`
height: 200px;
width :200px;
border-radius : 50%;
position : absolute;
background-color: white;
`
const Image = styled.img`
height : 75%;
z-index: 2;
`
const Info = styled.div`
opacity : 0;
background-color : rgba(0,0,0,0.2);
height: 100%;
display: flex;
align-items: center;
justify-content: center;
z-index: 3;
width: 100%;
position: absolute;
top : 0;
left : 0;
cursor : pointer;
&:hover {
    opacity: 1;
}
`
const Icon = styled.div`
width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 10px;
  transition: all 0.5s ease;
  &:hover {
    background-color: #e8f0f8da;
    transform: scale(1.1);
  }
`

const Product = ({item}) => {
  return (
    <Container>
        <Circle />
        <Image src = {item.img} />
        <Info>
            <Icon>
              <Link to={"/Cart"} className="nav-link"><ShoppingCartOutlined /></Link>
            </Icon>
            <Icon>
              <Link to={"/Product"} className="nav-link"><ShopOutlined /></Link>
            </Icon>
            <Icon>
              <SearchOutlined />
            </Icon>
            <Icon>
              <FavoriteBorderOutlined />
            </Icon>
        </Info>

    </Container>
  )
}

export default Product
