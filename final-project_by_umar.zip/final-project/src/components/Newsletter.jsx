import { Send } from "@material-ui/icons"
import { styled } from "styled-components"
import { mobile } from "../responsive"

const Container = styled.div`
 height : 60vh;
 display: flex ;
 background-color: whitesmoke;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 
`
const Title = styled.h1`
    font-style: 70px;
    margin-bottom: 20px;
    letter-spacing: 1px;
    ${mobile({fontSize : '50px'})}
`
const Desc = styled.div`
    font-size: 20px;
    font-weight: 500;
    margin-bottom: 10px ;
    letter-spacing: 1px;
    ${mobile({fontSize : '15px'})}
   
`
const InputContainer = styled.div`
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
    border: 1px lightgrey;
    width : 50%;
    height: 40px;
    background-color: white;
`
const Input= styled.input`
    flex:8;
    padding-left: 5px;
    letter-spacing: 2px;
    border: gray;
`
const Button = styled.button`
border: none;
background-color: teal;
color: white;
flex: 1;
cursor : pointer;  
`

const Newsletter = () => {
  return (
   <Container>
    <Title>Newsletter</Title>
    <Desc>Make every update to reach first to you.</Desc>
    <InputContainer>
    <Input placeholder="Type Your Mail...."/>
    <Button>
        <Send />
    </Button>
    
    </InputContainer>
   </Container>
  )
}

export default Newsletter
