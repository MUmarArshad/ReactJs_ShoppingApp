import React from "react";
import styled from "styled-components";
import {Search, ShoppingCartOutlined} from "@material-ui/icons";
import { Badge } from "@material-ui/core";
import { mobile } from "../responsive";
import { Link } from "react-router-dom";
import '../style.css'

 
 // Style for Items in Navbar
 const Container = styled.div`
  height: 60px;
  ${mobile({height : "15vh" ,})}
`;

const Wrapper = styled.div`
  padding: 10px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  ${mobile({ flexDirection : 'column' , justifyContent :'center'})}
`;

const Left = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  ${mobile({ margin : "5px 0px"})}
`;

const Language = styled.span`
  font-size: 14px;
  cursor: pointer;
  ${mobile({ display : "none"})}
`;

const SearchContainer = styled.div`
  border: 0.5px solid lightgray;
  display: flex;
  align-items: center;
  margin-left: 25px;
  padding: 5px;
  ${mobile({ display : "none"})}
`;

const Input = styled.input`
  border: none;
`;

const Center = styled.div`
  flex: 1;
  text-align: center;
`;

const Logo = styled.h1`
  font-weight: bold;
  ${mobile({ fontSize : "20px"})}
`;
const Right = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  ${mobile({ marginTop : "5px"})}
`;

const MenuItem = styled.div`
  font-size: 15px;
  cursor: pointer;
  margin-left: 25px;
  ${mobile({ fontSize: '15px' })} 
`;

const Navbar = () => {
  return (
    <Container>
      <Wrapper>
        <Left>
          <Language>EN</Language>
          <SearchContainer>
            <Input placeholder="Search" />
            <Search style={{ color: "gray", fontSize: 10 }} />
          </SearchContainer>
        </Left>
        <Center>
          <Logo><Link to={"/"} className="nav-link" >SHOPKRO.IO</Link></Logo>
        </Center>
        <Right>
          <MenuItem><Link to={"/Register"} className="nav-link" >REGISTER</Link></MenuItem>
          <MenuItem><Link to={"/Login"} className="nav-link" >SIGNIN</Link></MenuItem>
          <MenuItem>
              <Link to={"/Cart"} className="nav-link">
              <Badge badgeContent={4} color="primary" style={{ fontSize: 5 }} >  
              <ShoppingCartOutlined />
              </Badge>
              </Link>
            
          </MenuItem>
        </Right>
      </Wrapper>
    </Container>
  );
};

export default Navbar;