import React from 'react'
import { styled } from 'styled-components';
import { mobile } from '../responsive';

const Container = styled.div `
    background-color: teal;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
`
const Wrapper = styled.div`
display: flex;
background-color: whitesmoke;
display: flex;
flex-direction: column;
width: 30vw;
border-radius: 10px;
${mobile({ width : '90vw' })}
`

const Title = styled.h1`
font-size: 1.5rem;
margin: 1rem 1rem;
`

const Form = styled.form`
display: flex;
flex-direction: column;
padding: 0px .5rem ;
`

const Input = styled.input`
margin : .2rem;
border: none;
padding: .7rem;
border-radius: 2px;
`

const Agreement = styled.p`
font-size: 1rem;
font-weight: 500;
margin: 1rem 0;
padding-left: .5rem;
`

const Button = styled.button`
margin : 1rem;
padding: .5rem;
width: 40%;
border : none;
background-color: teal; 
transition: all .5sec ease;
border-radius: 10px ;
color: whitesmoke;
&:hover{
    scale : 1.1;
}
`


const Register = () => {
  return (
    <Container>
       
       <Wrapper> 
            <Title>CRETE AN ACCOUNT </Title>
            <Form>
              <Input placeholder="User Name" />
              <Input placeholder="Email" />
              <Input placeholder="Password" />
              <Input placeholder="Confirm Password" />              
              <Agreement>
                By Register you are agree to our term and services policy. 
              </Agreement>
               <Button>Create</Button>
            </Form>


       </Wrapper>

    </Container>
  )
}

export default Register;
