import React from 'react'
import { styled } from 'styled-components';
import { mobile } from '../responsive';

const Container = styled.div `
   width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://media.istockphoto.com/id/931769540/photo/half-turned-portrait-of-handsome-busy-confident-attractive-serious-minded-thoughtful-stunning.jpg?s=612x612&w=0&k=20&c=qIKqVyTwZh3L_z0mY3JFwlML3UFnhZqyu07QZ73IgX4=")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  
`;

const Wrapper = styled.div`
display: flex;
background-color: white;
display: flex;
flex-direction: column;
width: 30vw;
border-radius: 5px;
margin: 0 4rem;
${mobile({ width : '100vw'})}
`

const Title = styled.h1`
font-size: 1.5rem;
margin: 1rem 1rem;
display: flex;
justify-content: center;
`

const Form = styled.form`
display: flex;
flex-direction: column;
padding: 0px .5rem ;
`

const Input = styled.input`
margin : .2rem;
border: none;
padding: .7rem;
border-radius: 2px;
background-color: whitesmoke;
`
const Button = styled.button`
margin : .5rem;
padding: .5rem;
width: 40%;
border : none;
background-color: teal; 
transition: all .5sec ease;
border-radius: 5px ;
color : whitesmoke;

&:hover{
    scale : 1.1;
}

`
const P = styled.a`
 font-size: .8rem;
 margin-bottom: .5rem;
 margin-left: .3rem;
 text-decoration: underline;
 cursor: pointer;
 &:hover{
  color: purple;
 }
 ${mobile({ margin : '1rem 0' })}
`



const Login = () => {
  return (
    <Container>
       
       <Wrapper> 
            <Title>LOGIN </Title>
            <Form>
              <Input placeholder="Email" />
              <Input placeholder="Password" />              
               <Button>Log In</Button>
               <P>Forget Password</P>
               <P>Don't have an account Sign Up</P>
            </Form>


       </Wrapper>

    </Container>
  )
}

export default Login;
