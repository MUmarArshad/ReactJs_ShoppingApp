import Navbar from "../components/Navbar";
import Announcement from "../components/Announcement";
import { styled } from 'styled-components';
import Newsletter from "../components/Newsletter";
import Footer from "../Footer";
import { Add, Remove } from "@material-ui/icons";
import { mobile } from "../responsive";
import { useState } from "react";
import { Link } from "react-router-dom";

const Container = styled.div`
    
`
const Wrapper = styled.div`
    display: flex;
    padding: 50px;
    ${mobile({padding : "10px" , flexDirection : 'column'})}
`
const ImageContainer = styled.div`
    flex : 1;
    background-color: #abd2d2;
    
`
const Image = styled.img`
    height : 90vh;
    width : 100%;
    object-fit: cover;
    transition: all 0.5s ease;
    &:hover{
        scale: 1.2;
    }
    ${mobile({ height : '40vh'})}
`
const InfoContainer = styled.div`
    flex : 1;
    padding: 0px 50px;
    display: flex;
    justify-content: center;
    flex-direction: column;
    ${mobile({ marginTop : "10px" , flexDirection : 'column'})}
   `

const Title = styled.h1`
    font-size: 50px;
    font-weight: 500;
    margin-bottom: 20px;
`
const Desc = styled.p`
    font-size: 20px;
    font-weight: 500;
    margin-bottom: 20px;
`
const Price = styled.span`
    font-size: 30px;
    font-weight: 500;
`
const FilterContainer = styled.div`
  width: 50%;
  margin: 30px 0px;
  display: flex;
  justify-content: space-between;
`

const Filter = styled.div`
  display: flex;
  align-items: center;
  
`

const FilterTitle = styled.span`
  font-size: 20px;
  font-weight: 200;
`

const FilterColor = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: ${(props) => props.color};
  margin: 0px 5px;
  cursor: pointer;
  &:hover {
    scale: 1.05;
  }
`

const FilterSize = styled.select`
  margin-left: 10px;
  padding: 5px;
`
const AddContainer = styled.div`
  width: 50%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  ${mobile({ width : "100%" } )}
`;

const AmountContainer = styled.div`
  display: flex;
  align-items: center;
  font-weight: 700;
  
`;

const Amount = styled.span`
  width: 30px;
  height: 30px;
  border-radius: 10px;
  border: 1px solid teal;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0px 5px;
`;

const Button = styled.button`
  padding: 15px;
  border: 2px solid teal;
  background-color: white;
  cursor: pointer;
  font-weight: 500;

  &:hover{
      background-color: teal;
      scale: 1.05;
  }
`;
const Btn = styled.button`
background-color: transparent;
border: none;
`

const FilterSizeOption = styled.option``;
const Product = () => {
  let [state , setState] = useState(0);
  function increase(){
   setState(state+1);
  }
  function decrease(){
   if (state === 0) {
     state = 0;
   } else {
     setState(state-1);
   }
   
  }
  return (
    
    <Container>
     <Navbar />
     <Announcement />
   
     <Wrapper>
     <ImageContainer> 
        <Image src = "https://static.vecteezy.com/system/resources/previews/012/628/220/original/plain-black-t-shirt-on-transparent-background-free-png.png" />
     </ImageContainer>
        
        <InfoContainer>
            <Title>Black SKIT</Title>
            <Desc>The blue skit tshirt is one of our top selling product. Its worth buying</Desc>
            <Price>PKRS : 500</Price>
            <FilterContainer>
                <Filter>
                    <FilterTitle>Color</FilterTitle>
                    <FilterColor color = "black"></FilterColor >
                    <FilterColor color = "darkblue"></FilterColor>
                   <FilterColor color = "gray"></FilterColor>
                </Filter>
                
                <Filter>
              
              <FilterTitle>Size</FilterTitle>
              
              <FilterSize>
                    <FilterSizeOption> XS </FilterSizeOption>
                    <FilterSizeOption> S </FilterSizeOption>
                    <FilterSizeOption> M </FilterSizeOption>
                    <FilterSizeOption> L </FilterSizeOption>
                    <FilterSizeOption> XL </FilterSizeOption>
              </FilterSize>
            
            </Filter>
            
            </FilterContainer>
            <AddContainer>
              <AmountContainer>
              <Btn onClick={increase}><Add /></Btn>
              <Amount>{state}</Amount>
              <Btn onClick={decrease}><Remove /></Btn>

              </AmountContainer>
           <Link to={"/Cart"} className="nav-link"><Button>Add to Cart</Button></Link> 
            </AddContainer>
        </InfoContainer>
     </Wrapper>


     <Newsletter />
     <Footer />     
    </Container>
  )
}

export default Product;
