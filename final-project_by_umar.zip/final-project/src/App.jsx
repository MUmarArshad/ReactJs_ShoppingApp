import React from 'react'
import Cart from './Pages/Cart';
import Home from './Pages/Home'
import Login from './Pages/Login'
import Register from './Pages/Register'
import Product from './Pages/Product';
import ProductsPage from './Pages/ProductsPage'
import {  BrowserRouter, Route , Routes  } from 'react-router-dom';

const App = () => {
  return (
   <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home/>} />
      <Route path='/Login' element = {<Login />} />
      <Route path='/Register' element={<Register/>} />
      <Route path='/Login' element = {<Login />} />
      <Route path='/ProductPage' element = {<ProductsPage/>} />
      <Route path='/Product' element={<Product/>} />
      <Route path='/Cart' element = {<Cart/>}/>


    </Routes>
   </BrowserRouter>
  )
}

export default App;
